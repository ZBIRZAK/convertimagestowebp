<?php

if (!defined('ABSPATH')) {
    exit;
}

class WIM_WebP_Migrator
{
    const OPTION_KEY = 'wim_settings';
    const OPTION_BACKUP_DIR = 'wim_backup_dir';

    private static $instance = null;

    public static function instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct()
    {
        add_action('admin_menu', array($this, 'register_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));

        add_action('wp_ajax_wim_scan', array($this, 'ajax_scan'));
        add_action('wp_ajax_wim_convert_batch', array($this, 'ajax_convert_batch'));
        add_action('wp_ajax_wim_restore_batch', array($this, 'ajax_restore_batch'));

        add_filter('wp_get_attachment_url', array($this, 'filter_attachment_url'), 10, 2);
        add_filter('wp_get_attachment_image_src', array($this, 'filter_attachment_image_src'), 10, 4);
        add_filter('wp_calculate_image_srcset', array($this, 'filter_attachment_srcset'), 10, 5);
    }

    public function register_menu()
    {
        add_menu_page(
            'WP WebP Migrator',
            'WebP Migrator',
            'manage_options',
            'wim-webp-migrator',
            array($this, 'render_admin_page'),
            'dashicons-format-image'
        );
    }

    public function register_settings()
    {
        register_setting(self::OPTION_KEY, self::OPTION_KEY, array($this, 'sanitize_settings'));
    }

    public function sanitize_settings($input)
    {
        $defaults = $this->get_settings();

        return array(
            'quality' => isset($input['quality']) ? max(1, min(100, absint($input['quality']))) : $defaults['quality'],
            'batch_size' => isset($input['batch_size']) ? max(1, min(200, absint($input['batch_size']))) : $defaults['batch_size'],
            'replace_content_urls' => isset($input['replace_content_urls']) ? 1 : 0,
        );
    }

    private function get_settings()
    {
        $defaults = array(
            'quality' => 82,
            'batch_size' => 20,
            'replace_content_urls' => 1,
        );

        $saved = get_option(self::OPTION_KEY, array());

        return wp_parse_args($saved, $defaults);
    }

    public function enqueue_assets($hook_suffix)
    {
        if ('toplevel_page_wim-webp-migrator' !== $hook_suffix) {
            return;
        }

        wp_enqueue_style(
            'wim-admin-style',
            WIM_PLUGIN_URL . 'assets/admin.css',
            array(),
            '1.1.0'
        );

        wp_enqueue_script(
            'wim-admin-script',
            WIM_PLUGIN_URL . 'assets/admin.js',
            array(),
            '1.1.0',
            true
        );

        wp_localize_script(
            'wim-admin-script',
            'wimData',
            array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('wim_nonce'),
            )
        );
    }

    public function render_admin_page()
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        $settings = $this->get_settings();
        $stats = $this->get_stats();
        ?>
        <div class="wrap wim-wrap">
            <h1>WP WebP Migrator</h1>
            <p>Back up original uploads, generate WebP copies, and restore when needed.</p>

            <div class="wim-grid">
                <div class="wim-card">
                    <h2>Library Status</h2>
                    <div class="wim-stats">
                        <div><strong id="wim-total"><?php echo esc_html($stats['total_convertible']); ?></strong><span>Convertible (JPG/PNG)</span></div>
                        <div><strong id="wim-converted"><?php echo esc_html($stats['converted']); ?></strong><span>Converted</span></div>
                        <div><strong id="wim-pending"><?php echo esc_html($stats['pending']); ?></strong><span>Pending</span></div>
                    </div>
                    <p><strong>Backup folder:</strong> <code id="wim-backup-dir"><?php echo esc_html($stats['backup_dir']); ?></code></p>
                    <div class="wim-actions">
                        <button type="button" class="button" id="wim-scan-btn">Scan library</button>
                        <button type="button" class="button button-primary" id="wim-convert-btn">Convert pending images</button>
                        <button type="button" class="button" id="wim-restore-btn">Restore originals</button>
                    </div>
                    <p class="description">Conversion does not delete source JPG/PNG files, so old hardcoded URLs keep working.</p>
                    <div id="wim-log" class="wim-log"></div>
                </div>

                <div class="wim-card">
                    <h2>Settings</h2>
                    <form method="post" action="options.php">
                        <?php settings_fields(self::OPTION_KEY); ?>
                        <table class="form-table">
                            <tr>
                                <th scope="row"><label for="wim-quality">WebP quality</label></th>
                                <td>
                                    <input id="wim-quality" name="<?php echo esc_attr(self::OPTION_KEY); ?>[quality]" type="number" min="1" max="100" value="<?php echo esc_attr($settings['quality']); ?>" />
                                    <p class="description">Recommended range: 75-88.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label for="wim-batch-size">Batch size</label></th>
                                <td>
                                    <input id="wim-batch-size" name="<?php echo esc_attr(self::OPTION_KEY); ?>[batch_size]" type="number" min="1" max="200" value="<?php echo esc_attr($settings['batch_size']); ?>" />
                                    <p class="description">Lower this value if your hosting is slow.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Replace URLs in post content</th>
                                <td>
                                    <label>
                                        <input name="<?php echo esc_attr(self::OPTION_KEY); ?>[replace_content_urls]" type="checkbox" value="1" <?php checked(1, (int) $settings['replace_content_urls']); ?> />
                                        Replace old image URLs in post content with WebP URLs (all generated sizes).
                                    </label>
                                </td>
                            </tr>
                        </table>
                        <?php submit_button('Save settings'); ?>
                    </form>

                    <hr />
                    <h2>Plugin and Website</h2>
                    <p>Get full docs and updates for this plugin from our website.</p>
                    <p>
                        <a class="button button-secondary" href="https://www.convertimagestowebp.com/" target="_blank" rel="noopener noreferrer">Visit convertimagestowebp.com</a>
                        <a class="button button-secondary" href="https://www.convertimagestowebp.com/guides/wordpress-webp-plugin.html?utm_source=wp-plugin&utm_medium=admin&utm_campaign=wp-webp-migrator" target="_blank" rel="noopener noreferrer">Open Plugin Guide</a>
                    </p>
                </div>
            </div>
        </div>
        <?php
    }

    public function ajax_scan()
    {
        $this->assert_ajax_permission();
        wp_send_json_success($this->get_stats());
    }

    public function ajax_convert_batch()
    {
        $this->assert_ajax_permission();

        $settings = $this->get_settings();
        $batch_size = max(1, min(200, (int) $settings['batch_size']));

        $query = new WP_Query(array(
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'post_mime_type' => array('image/jpeg', 'image/png'),
            'posts_per_page' => $batch_size,
            'fields' => 'ids',
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'key' => '_wim_converted',
                    'compare' => 'NOT EXISTS',
                ),
                array(
                    'key' => '_wim_conversion_failed',
                    'compare' => 'NOT EXISTS',
                ),
            ),
        ));

        $converted = 0;
        $failed = 0;

        foreach ($query->posts as $attachment_id) {
            $ok = $this->convert_attachment((int) $attachment_id, $settings);
            if ($ok) {
                $converted++;
            } else {
                update_post_meta((int) $attachment_id, '_wim_conversion_failed', current_time('mysql'));
                $failed++;
            }
        }

        wp_send_json_success(array(
            'converted_in_batch' => $converted,
            'failed_in_batch' => $failed,
            'completed' => empty($query->posts),
            'stats' => $this->get_stats(),
        ));
    }

    public function ajax_restore_batch()
    {
        $this->assert_ajax_permission();

        $settings = $this->get_settings();
        $batch_size = max(1, min(200, (int) $settings['batch_size']));

        $query = new WP_Query(array(
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => $batch_size,
            'fields' => 'ids',
            'meta_query' => array(
                array(
                    'key' => '_wim_converted',
                    'value' => '1',
                ),
            ),
        ));

        $restored = 0;
        $failed = 0;

        foreach ($query->posts as $attachment_id) {
            $ok = $this->restore_attachment((int) $attachment_id, $settings);
            if ($ok) {
                $restored++;
            } else {
                $failed++;
            }
        }

        wp_send_json_success(array(
            'restored_in_batch' => $restored,
            'failed_in_batch' => $failed,
            'completed' => empty($query->posts),
            'stats' => $this->get_stats(),
        ));
    }

    private function assert_ajax_permission()
    {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Permission denied.'), 403);
        }

        check_ajax_referer('wim_nonce', 'nonce');
    }

    private function get_stats()
    {
        $convertible_query = new WP_Query(array(
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'post_mime_type' => array('image/jpeg', 'image/png'),
            'posts_per_page' => 1,
            'fields' => 'ids',
            'no_found_rows' => false,
        ));

        $converted_query = new WP_Query(array(
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => 1,
            'fields' => 'ids',
            'no_found_rows' => false,
            'meta_query' => array(
                array(
                    'key' => '_wim_converted',
                    'value' => '1',
                ),
            ),
        ));

        $total_convertible = (int) $convertible_query->found_posts;
        $converted = (int) $converted_query->found_posts;
        $pending = max(0, $total_convertible - $converted);

        $backup_dir = get_option(self::OPTION_BACKUP_DIR, '');

        return array(
            'total_convertible' => $total_convertible,
            'converted' => $converted,
            'pending' => $pending,
            'backup_dir' => $backup_dir ? $backup_dir : 'Not created yet',
        );
    }

    private function convert_attachment($attachment_id, $settings)
    {
        $uploads = wp_upload_dir();
        if (!empty($uploads['error'])) {
            return false;
        }

        $basedir = wp_normalize_path($uploads['basedir']);
        $baseurl = isset($uploads['baseurl']) ? untrailingslashit($uploads['baseurl']) : '';
        $quality = max(1, min(100, (int) $settings['quality']));

        $metadata = wp_get_attachment_metadata($attachment_id);
        if (!is_array($metadata) || empty($metadata['file'])) {
            return false;
        }

        $original_attached_file = get_post_meta($attachment_id, '_wp_attached_file', true);
        $original_metadata = $metadata;
        $original_mime = get_post_mime_type($attachment_id);

        $original_path = get_attached_file($attachment_id);
        if (!$original_path || !file_exists($original_path)) {
            return false;
        }

        $targets = $this->build_target_list($metadata, $original_path);
        if (empty($targets)) {
            return false;
        }

        $backup_root = $this->ensure_backup_root($basedir);
        if (!$backup_root) {
            return false;
        }

        $backup_map = array();
        $relative_map = array();
        $url_map = array();

        foreach ($targets as $target) {
            $source_abs = $target['abs'];
            $source_rel = $target['rel'];

            if (!file_exists($source_abs) || !$this->is_supported_source($source_abs)) {
                continue;
            }

            $backup_rel = $this->backup_file($source_abs, $basedir, $backup_root);
            if (!$backup_rel) {
                continue;
            }

            $dest_abs = preg_replace('/\.(jpe?g|png)$/i', '.webp', $source_abs);
            $dest_rel = preg_replace('/\.(jpe?g|png)$/i', '.webp', $source_rel);
            if (!$dest_abs || !$dest_rel) {
                continue;
            }

            $converted = $this->convert_file_to_webp($source_abs, $dest_abs, $quality);
            if (!$converted || !file_exists($dest_abs)) {
                continue;
            }

            $backup_map[] = array(
                'source_rel' => $source_rel,
                'backup_rel' => $backup_rel,
                'webp_rel' => $dest_rel,
            );
            $relative_map[$source_rel] = $dest_rel;

            if ($baseurl) {
                $old_url = $this->rel_to_upload_url($baseurl, $source_rel);
                $new_url = $this->rel_to_upload_url($baseurl, $dest_rel);
                $url_map[$old_url] = $new_url;
            }
        }

        if (empty($relative_map)) {
            return false;
        }

        if (!empty($settings['replace_content_urls']) && !empty($url_map)) {
            $this->replace_url_map_in_posts($url_map);
        }

        update_post_meta($attachment_id, '_wim_converted', 1);
        delete_post_meta($attachment_id, '_wim_conversion_failed');
        update_post_meta($attachment_id, '_wim_backup_map', $backup_map);
        update_post_meta($attachment_id, '_wim_relative_map', $relative_map);
        update_post_meta($attachment_id, '_wim_url_map', $url_map);
        update_post_meta($attachment_id, '_wim_original_attached_file', $original_attached_file);
        update_post_meta($attachment_id, '_wim_original_metadata', $original_metadata);
        update_post_meta($attachment_id, '_wim_original_mime', $original_mime);

        return true;
    }

    private function restore_attachment($attachment_id, $settings)
    {
        $uploads = wp_upload_dir();
        if (!empty($uploads['error'])) {
            return false;
        }

        $basedir = wp_normalize_path($uploads['basedir']);

        $backup_map = get_post_meta($attachment_id, '_wim_backup_map', true);
        $url_map = get_post_meta($attachment_id, '_wim_url_map', true);
        $original_attached_file = get_post_meta($attachment_id, '_wim_original_attached_file', true);
        $original_metadata = get_post_meta($attachment_id, '_wim_original_metadata', true);
        $original_mime = get_post_meta($attachment_id, '_wim_original_mime', true);
        $legacy_old_url = get_post_meta($attachment_id, '_wim_old_url', true);
        $legacy_new_url = get_post_meta($attachment_id, '_wim_new_url', true);

        if (!is_array($backup_map) || empty($backup_map) || !is_array($original_metadata) || empty($original_attached_file)) {
            return false;
        }

        foreach ($backup_map as $item) {
            if (empty($item['source_rel']) || empty($item['backup_rel'])) {
                continue;
            }

            $source_abs = $basedir . '/' . ltrim(wp_normalize_path($item['source_rel']), '/');
            $backup_abs = $basedir . '/' . ltrim(wp_normalize_path($item['backup_rel']), '/');

            if (!file_exists($backup_abs)) {
                continue;
            }

            wp_mkdir_p(dirname($source_abs));
            copy($backup_abs, $source_abs);

            if (!empty($item['webp_rel'])) {
                $webp_abs = $basedir . '/' . ltrim(wp_normalize_path($item['webp_rel']), '/');
                if (file_exists($webp_abs)) {
                    @unlink($webp_abs);
                }
            }
        }

        wp_update_attachment_metadata($attachment_id, $original_metadata);
        update_attached_file($attachment_id, $original_attached_file);
        wp_update_post(array(
            'ID' => $attachment_id,
            'post_mime_type' => $original_mime ? $original_mime : 'image/jpeg',
        ));

        if (!empty($settings['replace_content_urls'])) {
            if (is_array($url_map) && !empty($url_map)) {
                $this->replace_url_map_in_posts(array_flip($url_map));
            } elseif ($legacy_old_url && $legacy_new_url && $legacy_old_url !== $legacy_new_url) {
                $this->replace_urls_in_posts($legacy_new_url, $legacy_old_url);
            }
        }

        delete_post_meta($attachment_id, '_wim_converted');
        delete_post_meta($attachment_id, '_wim_backup_map');
        delete_post_meta($attachment_id, '_wim_relative_map');
        delete_post_meta($attachment_id, '_wim_url_map');
        delete_post_meta($attachment_id, '_wim_original_attached_file');
        delete_post_meta($attachment_id, '_wim_original_metadata');
        delete_post_meta($attachment_id, '_wim_original_mime');
        delete_post_meta($attachment_id, '_wim_old_url');
        delete_post_meta($attachment_id, '_wim_new_url');
        delete_post_meta($attachment_id, '_wim_conversion_failed');

        return true;
    }

    private function build_target_list($metadata, $original_path)
    {
        $targets = array();
        $main_rel = wp_normalize_path($metadata['file']);
        $main_abs = wp_normalize_path($original_path);

        $targets[] = array(
            'rel' => ltrim($main_rel, '/'),
            'abs' => $main_abs,
        );

        if (empty($metadata['sizes']) || !is_array($metadata['sizes'])) {
            return $targets;
        }

        $main_dir_abs = wp_normalize_path(dirname($main_abs));
        $main_dir_rel = dirname($main_rel);
        $main_dir_rel = '.' === $main_dir_rel ? '' : trailingslashit($main_dir_rel);

        foreach ($metadata['sizes'] as $size) {
            if (empty($size['file'])) {
                continue;
            }

            $rel = wp_normalize_path($main_dir_rel . $size['file']);
            $abs = wp_normalize_path($main_dir_abs . '/' . $size['file']);

            $targets[] = array(
                'rel' => ltrim($rel, '/'),
                'abs' => $abs,
            );
        }

        return $targets;
    }

    private function ensure_backup_root($basedir)
    {
        $existing = get_option(self::OPTION_BACKUP_DIR, '');
        if ($existing) {
            return wp_normalize_path($existing);
        }

        $backup_root = wp_normalize_path($basedir . '/wim-backups/' . gmdate('Ymd-His'));
        wp_mkdir_p($backup_root);
        update_option(self::OPTION_BACKUP_DIR, $backup_root, false);

        return $backup_root;
    }

    private function backup_file($source_abs, $basedir, $backup_root)
    {
        $source_abs = wp_normalize_path($source_abs);
        $basedir = wp_normalize_path($basedir);
        $backup_root = wp_normalize_path($backup_root);

        $source_rel = ltrim(str_replace($basedir, '', $source_abs), '/');
        if (!$source_rel) {
            return false;
        }

        $backup_abs = $backup_root . '/' . $source_rel;
        wp_mkdir_p(dirname($backup_abs));

        if (!file_exists($backup_abs)) {
            if (!copy($source_abs, $backup_abs)) {
                return false;
            }
        }

        return ltrim(str_replace($basedir, '', $backup_abs), '/');
    }

    private function is_supported_source($file_abs)
    {
        return (bool) preg_match('/\.(jpe?g|png)$/i', $file_abs);
    }

    private function convert_file_to_webp($source_abs, $dest_abs, $quality)
    {
        if (class_exists('Imagick')) {
            try {
                $image = new Imagick($source_abs);
                $image->setImageFormat('webp');
                $image->setImageCompressionQuality($quality);
                $ok = $image->writeImage($dest_abs);
                $image->clear();
                $image->destroy();
                if ($ok) {
                    return true;
                }
            } catch (Exception $e) {
            }
        }

        if (!function_exists('imagewebp')) {
            return false;
        }

        $type = function_exists('exif_imagetype') ? @exif_imagetype($source_abs) : false;
        if (!$type) {
            $ext = strtolower(pathinfo($source_abs, PATHINFO_EXTENSION));
            if (in_array($ext, array('jpg', 'jpeg'), true)) {
                $type = IMAGETYPE_JPEG;
            } elseif ('png' === $ext) {
                $type = IMAGETYPE_PNG;
            }
        }

        if (IMAGETYPE_JPEG === $type && function_exists('imagecreatefromjpeg')) {
            $resource = @imagecreatefromjpeg($source_abs);
        } elseif (IMAGETYPE_PNG === $type && function_exists('imagecreatefrompng')) {
            $resource = @imagecreatefrompng($source_abs);
            if ($resource) {
                if (function_exists('imagepalettetotruecolor')) {
                    imagepalettetotruecolor($resource);
                }
                imagealphablending($resource, true);
                imagesavealpha($resource, true);
            }
        } else {
            return false;
        }

        if (!$resource) {
            return false;
        }

        $ok = imagewebp($resource, $dest_abs, $quality);
        imagedestroy($resource);

        return (bool) $ok;
    }

    public function filter_attachment_url($url, $attachment_id)
    {
        if (!$url || !$this->is_attachment_converted($attachment_id)) {
            return $url;
        }

        return $this->map_url_to_webp((int) $attachment_id, $url);
    }

    public function filter_attachment_image_src($image, $attachment_id, $size, $icon)
    {
        if (!is_array($image) || empty($image[0]) || !$this->is_attachment_converted($attachment_id)) {
            return $image;
        }

        $image[0] = $this->map_url_to_webp((int) $attachment_id, $image[0]);
        return $image;
    }

    public function filter_attachment_srcset($sources, $size_array, $image_src, $image_meta, $attachment_id)
    {
        if (!is_array($sources) || !$this->is_attachment_converted($attachment_id)) {
            return $sources;
        }

        foreach ($sources as $width => $source) {
            if (empty($source['url'])) {
                continue;
            }
            $sources[$width]['url'] = $this->map_url_to_webp((int) $attachment_id, $source['url']);
        }

        return $sources;
    }

    private function replace_urls_in_posts($old_url, $new_url)
    {
        global $wpdb;

        if (!$old_url || !$new_url || $old_url === $new_url) {
            return;
        }

        $like = '%' . $wpdb->esc_like($old_url) . '%';
        $sql = $wpdb->prepare(
            "UPDATE {$wpdb->posts} SET post_content = REPLACE(post_content, %s, %s) WHERE post_content LIKE %s",
            $old_url,
            $new_url,
            $like
        );
        $wpdb->query($sql);
    }

    private function replace_url_map_in_posts($url_map)
    {
        if (!is_array($url_map) || empty($url_map)) {
            return;
        }

        foreach ($url_map as $old_url => $new_url) {
            if (!is_string($old_url) || !is_string($new_url)) {
                continue;
            }
            $this->replace_urls_in_posts($old_url, $new_url);
        }
    }

    private function is_attachment_converted($attachment_id)
    {
        return (bool) get_post_meta((int) $attachment_id, '_wim_converted', true);
    }

    private function map_url_to_webp($attachment_id, $url)
    {
        if (!is_string($url) || '' === $url) {
            return $url;
        }

        $url_map = get_post_meta($attachment_id, '_wim_url_map', true);
        if (is_array($url_map) && isset($url_map[$url])) {
            $candidate = $url_map[$url];
            if ($this->url_points_to_existing_file($candidate)) {
                return $candidate;
            }
        }

        $candidate = preg_replace('/\.(jpe?g|png)(\?.*)?$/i', '.webp$2', $url);
        if (is_string($candidate) && $candidate !== $url && $this->url_points_to_existing_file($candidate)) {
            return $candidate;
        }

        return $url;
    }

    private function rel_to_upload_url($baseurl, $rel_path)
    {
        $baseurl = untrailingslashit((string) $baseurl);
        $rel_path = ltrim(str_replace('\\', '/', (string) $rel_path), '/');
        return $baseurl . '/' . $rel_path;
    }

    private function url_points_to_existing_file($url)
    {
        $uploads = wp_upload_dir();
        if (!empty($uploads['error']) || empty($uploads['baseurl']) || empty($uploads['basedir'])) {
            return false;
        }

        $baseurl = untrailingslashit($uploads['baseurl']);
        $basedir = wp_normalize_path($uploads['basedir']);
        $plain_url = strtok((string) $url, '?');
        if (!is_string($plain_url) || 0 !== strpos($plain_url, $baseurl . '/')) {
            return false;
        }

        $rel = ltrim(substr($plain_url, strlen($baseurl)), '/');
        $file = wp_normalize_path($basedir . '/' . $rel);
        return file_exists($file);
    }
}
