=== WP WebP Migrator ===
Contributors: convertimagestowebp
Tags: webp, images, media, optimization, performance
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Back up uploads, convert JPG/PNG media to WebP, and restore originals from a dashboard.

== Description ==
WP WebP Migrator adds an admin dashboard where site owners can:

1. Scan media library conversion status.
2. Back up image files into `wp-content/uploads/wim-backups/...`.
3. Convert JPG and PNG files (including generated sizes) to WebP.
4. Replace attachment metadata and optionally replace URLs in post content.
5. Restore converted images from backup.

== Installation ==
1. Upload the plugin folder to `/wp-content/plugins/wp-webp-migrator`.
2. Activate **WP WebP Migrator**.
3. Open **WebP Migrator** in wp-admin.
4. Review settings, then run **Convert pending images**.

== Notes ==
- The plugin requires Imagick or GD with WebP support.
- Conversion and restore process in batches to avoid timeouts.
- Always test on staging before production.
